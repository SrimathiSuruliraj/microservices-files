package com.composite.compositems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.composite.compositems.clients.EmployeeServiceProxy;
import com.composite.compositems.entities.Employee;

@RestController
public class CompositeRestController {
	@Autowired
	private EmployeeServiceProxy proxy;
	
	@GetMapping("/employees")
	public List<Employee> getEmployees() {
		return proxy.getEmployees();
		
	}
	@GetMapping("/employees/{id}")
	public Employee getEmployee(@PathVariable("id") int id) {
		return proxy.getEmployee(id);
	}
	@PostMapping("/employees")
	public ResponseEntity<Employee> createEmployee(@RequestBody Employee emp) {
		return proxy.createEmployee(emp);
	}
	@PutMapping("/employees/{id}")
	public void updateEmployee(@PathVariable("id") int id,@RequestBody Employee emp) {
		 proxy.updateEmployee(id, emp);
	}
	@DeleteMapping("/employees/{id}")
	public void deleteEmployee(@PathVariable("id") int id) {
		proxy.deleteEmployee(id);
	}
	
	

}
