package com.composite.compositems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompositeMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
