package com.zull.Zuulgatewayclient.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.DiscoveryClient;
import com.netflix.discovery.EurekaClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.netflix.ribbon.proxy.annotation.Hystrix;

@RestController
public class ClientController {
	@Autowired
	private EurekaClient eurekaClient;
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/")
	@HystrixCommand(fallbackMethod="defaultMethod",
			commandProperties= {
					@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="2000"),
					@HystrixProperty(name="circuitBreaker.requestVolumeThreshold",value="2"),
					@HystrixProperty(name="circuitBreaker.errorThresholdPercentage",value="50"),
					@HystrixProperty(name="circuitBreaker.sleepWindowInMilliseconds",value="1000")
					
			},
			threadPoolKey="serviceAppPool",
			threadPoolProperties= {
							@HystrixProperty(name="coreSize",value="5"),
							@HystrixProperty(name="maxQueueSize",value="2")
					}
	
			)
	
	public String invokeService() {
		//List<InstanceInfo> instancesById = discoveryClient.getInstancesById("zuul-gateway");
		
		
	
		//InstanceInfo instanceinfo = eurekaClient.getNextServerFromEureka("zuul-gateway",false);
		String baseUrl="http://localhost:9191/api/serviceapp/greetings";
		System.out.println("Base URL:"+baseUrl);
		return restTemplate.getForObject(baseUrl, String.class);
		
	}
	public String defaultMethod() {
		return "Default Message";
	}
	
	

	

}
