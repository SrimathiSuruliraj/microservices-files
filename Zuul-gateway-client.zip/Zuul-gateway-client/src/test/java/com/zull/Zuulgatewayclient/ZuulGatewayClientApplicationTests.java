package com.zull.Zuulgatewayclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulGatewayClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
