package com.example.productMs.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.productMs.model.Product;

public interface ProductRepo extends MongoRepository<Product, String>{
	Product findByProductId(String productId);

}
