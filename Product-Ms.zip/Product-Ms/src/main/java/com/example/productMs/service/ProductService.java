package com.example.productMs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.productMs.model.Product;
import com.example.productMs.repository.ProductRepo;


@Service
public class ProductService {
	
	@Autowired
	ProductRepo prodRepo;
	
	public Product saveData(Product product)
    {
        prodRepo.save(product);
        return product;
    }
	
	public List<Product> findAll()
    {
        return prodRepo.findAll();
    }
	
    public Product findBy(String productId)
    {
        return prodRepo.findByProductId(productId);
    }
    
    public Product updateProduct(String productId, Product product) {
        
        Product prod=prodRepo.findByProductId(productId);
        product.setProductPrice(prod.getProductPrice());
        product.setProductName(prod.getProductName());
        prodRepo.save(product);
        return product;
        
    }
    public String deleteAll()
    {
        prodRepo.deleteAll();
        return "All product data are Deleted";
    }
    
    public String deleteProduct(String productId) {
    	prodRepo.deleteById(productId);
    	return "Product deleted";
    }


}
