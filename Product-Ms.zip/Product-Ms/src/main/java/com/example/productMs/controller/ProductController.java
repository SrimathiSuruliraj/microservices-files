package com.example.productMs.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.productMs.model.Product;
import com.example.productMs.service.ProductService;

@Controller

public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@RequestMapping("/productData")
	public String productForm() {
		return "Product";
	}
	
	@ResponseBody
	@PostMapping(value="/save")
	public Product save(@RequestParam("productId") String productId,@RequestParam("productName") String productName,@RequestParam("productPrice") int productPrice) {
		return productService.saveData(new Product(productId,productName,productPrice));
	}
	
	@PostMapping("/addProduct")
	public ResponseEntity<Product> addProduct(@RequestBody Product product){
		Product savedProduct=productService.saveData(product);
		
		URI location=ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedProduct.getProductId()).toUri();
        return ResponseEntity.created(location).build();
	}
	
    @ResponseBody
    @GetMapping(path="/products")
    public List<Product> getProducts() {
        return productService.findAll();
    }
    
    @ResponseBody
    @RequestMapping(path="/products/{productId}")
    public Product getProduct(@PathVariable("productId") String productId) {
        System.out.println("Product ID is:"+productId);
        return productService.findBy(productId);
    }
    @PutMapping("/products/{productId}")
    public void updateProduct(@PathVariable String productId,@RequestBody Product product) {
        Product updatedProduct=productService.updateProduct(productId, product);
        if(updatedProduct==null)
            System.out.println("Product Id Not Found");
            
        }
        
    @ResponseBody
    @RequestMapping(path="/deleteAll")
    public String deleteAll() {
        return productService.deleteAll();
    }
    
    @RequestMapping("deleteProduct/{productId}")
    public String deleteProduct(@PathVariable("productId") String productId) {
    	return productService.deleteProduct(productId);
    }


}
