package com.example.customerms.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Customer {
	@Id
	String customerId;
	String customerName;
	String customerAddress;
	public String getCustomerId() {
    	return customerId;
	}
	public void setCustomerId(String customerId) {
    	this.customerId = customerId;
	}
	public String getCustomerName() {
    	return customerName;
	}
	public void setCustomerName(String customerName) {
    	this.customerName = customerName;
	}
	public String getCustomerAddress() {
    	return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
    	this.customerAddress = customerAddress;
	}
	public Customer(String customerId, String customerName, String customerAddress) {
    	super();
    	this.customerId = customerId;
    	this.customerName = customerName;
    	this.customerAddress = customerAddress;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + "]";
	}
	

}
