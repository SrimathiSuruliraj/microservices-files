package com.example.customerms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customerms.model.Customer;
import com.example.customerms.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	public Customer saveData(Customer customer)
    {
        customerRepository.save(customer);
        return customer;
    }
    public List<Customer> findAll()
    {
        return customerRepository.findAll();
    }
    public Customer findBy(String customerId)
    {
        return customerRepository.findByCustomerId(customerId);
    }
    
    public Customer updateCustomer(String customerId, Customer custmr) {
        
        Customer customer=customerRepository.findByCustomerId(customerId);
        customer.setCustomerAddress(custmr.getCustomerAddress());
        customer.setCustomerName(custmr.getCustomerName());
        customerRepository.save(customer);
        return customer;
        
    }
    public String deleteAll()
    {
        customerRepository.deleteAll();
        return "All customer data are Deleted";
    }
    
    public String deleteCustomer(String customerId) {
    	customerRepository.deleteById(customerId);
    	return "Customer deleted";
    }

}
