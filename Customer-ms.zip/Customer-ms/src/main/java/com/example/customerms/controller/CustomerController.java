package com.example.customerms.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.customerms.model.Customer;
import com.example.customerms.service.CustomerService;

@Controller

public class CustomerController {
	@Autowired
	CustomerService customerService;
	@RequestMapping("/customerForm")
	public String customerForm() {
		return "Customer";
	}
	@ResponseBody
	@PostMapping(value="/save")
	public Customer save(@RequestParam("customerId") String customerId,@RequestParam("customerName") String customerName,@RequestParam("customerAddress") String customerAddress) {
		return customerService.saveData(new Customer(customerId,customerName,customerAddress));
	}
	@PostMapping("/addCustomer")
	public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer){
		Customer savedCustomer=customerService.saveData(customer);
		
		URI location=ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedCustomer.getCustomerId()).toUri();
        return ResponseEntity.created(location).build();
     
	}
    @ResponseBody
    @GetMapping(path="/customers")
    public List<Customer> getCustomers() {
        return customerService.findAll();
    }
    
    @ResponseBody
    @RequestMapping(path="/customers/{customerId}")
    public Customer getCustomer(@PathVariable("customerId") String customerId) {
        System.out.println("Customer ID is:"+customerId);
        return customerService.findBy(customerId);
    }
    @PutMapping("/customers/{customerId}")
    public void updateCustomer(@PathVariable String customerId,@RequestBody Customer customer) {
        Customer updatedCustomer=customerService.updateCustomer(customerId, customer);
        if(updatedCustomer==null)
            System.out.println("Customer Id Not Found");
            
        }
        
    @ResponseBody
    @RequestMapping(path="/deleteAll")
    public String deleteAll() {
        return customerService.deleteAll();
    }
    
    @RequestMapping("deleteCustomer/{customerId}")
    public String deleteCustomer(@PathVariable("customerId") String customerId) {
    	return customerService.deleteCustomer(customerId);
    }

}
